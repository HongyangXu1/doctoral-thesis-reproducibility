/* Per-truck command lifecycle. Motion, fuel and traffic rules remain in the simulator. */
(function (root) {
  'use strict';
  const requireValue = (condition, message) => { if (!condition) throw new Error(message); };
  const travel = truck => ['loaded_trip', 'empty_trip'].includes(truck.phase);
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  function create(env, control, dataset, spec, hash, lifetime) {
    requireValue(spec?.state_dimension === 40 && spec.fields.length === 40
      && spec.normalizers.length === 40 && spec.control_lifetimes.includes(lifetime)
      && /^[a-f0-9]{64}$/.test(hash), 'Invalid truck controller interface');
    const sessions = new Map();
    const executionRows = new Map();
    const legs = new Map(env.trucks().map(t => [String(t.id), travel(t) ? 1 : 0]));
    const frozenFleet = env.trucks().map(t => [String(t.id), t.routeId, t.truckType]);
    const frozenConfig = env.configurationKey();
    const stepSeconds = Number(dataset.config.delta_t_seconds || 1);
    requireValue(Number.isFinite(stepSeconds) && stepSeconds > 0 && stepSeconds <= 30, 'Invalid execution step');
    let lastDecision = null;
    let busy = false;
    let stepSnapshot = null;
    dataset.chapter5ControlLifecycleRows = [];
    const log = (truckId, event, reason, extra = {}) => dataset.chapter5ControlLifecycleRows.push({
      time_s: env.now(), truck_id: truckId, leg_sequence: legs.get(truckId), event, reason, ...extra
    });
    function release(id, reason) {
      executionRows.delete(id);
      if (sessions.delete(id)) { control.releaseCount += 1; log(id, 'release', reason); }
      delete control.targetSpeedsByConvoyId[id];
      delete control.activeActionsByConvoyId[id];
      delete control.activeRisksByConvoyId[id];
      control.previousActionsByConvoyId[id] = 0;
    }
    function phaseChanged(truck, nextPhase) {
      if (truck.phase === nextPhase) return;
      const id = String(truck.id);
      release(id, 'phase_change');
      if (['loaded_trip', 'empty_trip'].includes(nextPhase)) legs.set(id, (legs.get(id) || 0) + 1);
    }
    function reconcile() {
      if (!same(env.trucks().map(t => [String(t.id), t.routeId, t.truckType]), frozenFleet)) {
        for (const id of [...sessions.keys()]) release(id, 'fleet_changed');
        throw new Error('Truck fleet/route changed during control');
      }
      for (const truck of env.trucks()) {
        const id = String(truck.id), session = sessions.get(id);
        if (!session) continue;
        if (!travel(truck) || session.phase !== truck.phase || session.leg !== legs.get(id)) {
          release(id, 'leg_changed');
        } else if (lifetime === 'truck_risk_release'
          && env.nearestRisk(truck, control.lastPrediction)?.node_id !== session.node) {
          release(id, 'risk_ineligible');
        }
      }
    }
    function contexts(prediction, time) {
      requireValue(Array.isArray(prediction?.horizons) && prediction.horizons.length === 3,
        'Missing truck forecast horizons');
      for (const [i, h] of prediction.horizons.entries()) {
        requireValue(h.horizon_seconds === (i + 1) * 30 && Array.isArray(h.nodes), 'Invalid forecast horizon');
        requireValue(new Set(h.nodes.map(n => n.node_id)).size === h.nodes.length, 'Duplicate forecast node');
        for (const row of h.nodes) {
          requireValue(typeof row.detection_enabled === 'boolean'
            && Number.isFinite(row.predicted_speed_kmh) && row.predicted_speed_kmh >= 0
            && ['predicted_presence_probability', 'predicted_conditional_obstruction_probability',
              'predicted_operational_obstruction_probability', 'probability_threshold'].every(k =>
              Number.isFinite(row[k]) && row[k] >= 0 && row[k] <= 1), 'Malformed forecast node');
        }
      }
      const result = new Map();
      for (const truck of env.trucks().filter(travel)) {
        const options = [];
        for (const h of prediction.horizons) for (const row of h.nodes) {
          if (!row.detection_enabled || env.nodeType(row.node_id) !== 'junction') continue;
          const distance = env.distanceMeters(truck, row.node_id);
          const eta = distance / env.etaSpeed(truck) * 3.6;
          if (!Number.isFinite(distance) || distance < 0 || distance > 750 || eta > 90
            || h.horizon_seconds !== Math.max(30, Math.ceil(eta / 30) * 30)) continue;
          const latest = env.latestNode(dataset, row.node_id, time);
          options.push({row, distance, eta, horizon: h.horizon_seconds, latest});
        }
        options.sort((a, b) => a.eta - b.eta || String(a.row.node_id).localeCompare(String(b.row.node_id)));
        result.set(String(truck.id), options);
      }
      return result;
    }
    function observe(truck, time, allContexts) {
      const id = String(truck.id), session = sessions.get(id);
      const baseline = env.baseline(truck), range = env.range(truck), work = env.workload(truck, time);
      requireValue(spec.truck_types.includes(truck.truckType), 'Unknown truck type');
      const intent = control.activeActionsByConvoyId[id] ?? 0;
      const context = allContexts.get(id)?.[0];
      const raw = [Number(truck.currentSpeedKmh || 0), baseline, Number(truck.phase === 'loaded_trip'), intent,
        env.clamp(baseline + intent, range.minKmh, range.maxKmh), range.maxKmh, Number(range.maxKmh === 0),
        env.remainingFraction(truck), work.resource_queue_ratio, work.progress,
        work.estimated_remaining_completion_s, env.taskProgress(), time - session.started, time - session.triggered];
      if (context) {
        const {row, distance, eta, horizon, latest} = context;
        raw.push(1, distance, eta, horizon, row.predicted_speed_kmh, row.predicted_presence_probability,
          row.predicted_conditional_obstruction_probability, row.predicted_operational_obstruction_probability,
          latest.presence, latest.speed, env.waiting(row.node_id),
          Number(row.predicted_operational_obstruction_probability >= row.probability_threshold));
      } else raw.push(...Array(12).fill(0));
      const others = [];
      if (context) for (const other of env.trucks()) {
        if (String(other.id) === id || (other.routeId === truck.routeId && other.phase === truck.phase)) continue;
        const c = allContexts.get(String(other.id))?.find(x => x.row.node_id === context.row.node_id
          && x.horizon === context.horizon);
        if (c) others.push({truck: other, context: c});
      }
      others.sort((a, b) => Math.abs(a.context.eta - context.eta) - Math.abs(b.context.eta - context.eta)
        || String(a.truck.id).localeCompare(String(b.truck.id)));
      const other = others[0];
      if (other) raw.push(1, Number(other.truck.currentSpeedKmh || 0), env.baseline(other.truck),
        Number(other.truck.phase === 'loaded_trip'), other.context.eta, other.context.eta - context.eta,
        control.activeActionsByConvoyId[other.truck.id] ?? 0);
      else raw.push(...Array(7).fill(0));
      raw.push(...spec.truck_types.map(type => Number(type === truck.truckType)));
      requireValue(raw.length === 40 && raw.every(Number.isFinite), 'Invalid truck observation');
      let clipped = 0;
      const vector = raw.map((x, i) => {
        const scaled = x / spec.normalizers[i];
        // Physical speed clamps reject negatives; signed observations must retain them.
        const value = Math.min(1, Math.max(spec.signed_indices.includes(i) ? -1 : 0, scaled));
        if (value !== scaled) clipped += 1;
        return value;
      });
      return {truck_id: id, leg_sequence: session.leg, decision_time_s: time, interface_hash: hash,
        route_id: truck.routeId, phase: truck.phase, risk_node_id: context?.row.node_id ?? null,
        trigger_node_id: session.node, counterpart_truck_id: other ? String(other.truck.id) : null,
        state_input: Object.fromEntries(spec.fields.map((name, i) => [name, raw[i]])),
        state_vector: vector, clipped_field_count: clipped, new_session: session.started === time};
    }
    function fleetState(time) {
      return {time_s: time, delivered_tons: env.delivered(), trucks: env.trucks().map(t => ({
        truck_id: String(t.id), route_id: String(t.routeId), truck_type: t.truckType, phase: t.phase,
        current_speed_kmh: Number(t.currentSpeedKmh || 0), distance_px: Number(t.distancePx || 0),
        remaining_leg_fraction: travel(t) ? env.remainingFraction(t) : 0,
        leg_sequence: legs.get(String(t.id)) || 0, session_active: sessions.has(String(t.id)),
        intent_offset_kmh: control.activeActionsByConvoyId[t.id] ?? 0,
        session_age_s: sessions.has(String(t.id)) ? time - sessions.get(String(t.id)).started : 0,
        baseline_speed_kmh: env.baseline(t)
      }))};
    }
    async function decide(prediction, time) {
      requireValue(!busy && time >= 360 && time % 30 === 0
        && (lastDecision === null || time === lastDecision + 30), 'Stale or overlapping truck decision');
      busy = true;
      try {
        requireValue(env.configurationKey() === frozenConfig, 'Controller configuration changed during run');
        reconcile();
        const allContexts = contexts(prediction, time);
        control.lastPrediction = prediction;
        control.lastPredictionTimeSeconds = time;
        reconcile();
        const raw = env.rawRisks(prediction);
        const pairs = env.pairs(raw, time, control.pairMatchingDiagnostics);
        control.rawEligibleCandidateCount += raw.length;
        control.matchedPairDecisionCount += pairs.length;
        for (const pair of pairs) for (const member of [pair.priority, pair.counterpart]) {
          const t = member.convoy, id = String(t.id);
          if (!sessions.has(id)) {
            sessions.set(id, {leg: legs.get(id), phase: t.phase, node: member.risk.node_id,
              started: time, triggered: time});
            log(id, 'activate', 'predicted_pair', {trigger_node_id: member.risk.node_id});
          } else sessions.get(id).triggered = time;
        }
        const candidates = env.trucks().filter(t => sessions.has(String(t.id))).map(t => observe(t, time, allContexts));
        const fleet = fleetState(time), mask = control.agentIds.map(id => Number(sessions.has(id)));
        const request = {schema_version: 4, interface_hash: hash, control_lifetime: lifetime,
          request_id: `truck-${dataset.config.initial_release_schedule.random_seed}-${time}`,
          decision_time_s: time, candidates};
        const response = await env.select(request);
        requireValue(response?.schema_version === 4 && response.interface_hash === hash
          && response.request_id === request.request_id && response.decision_time_s === time
          && Array.isArray(response.actions) && response.actions.length === candidates.length, 'Stale truck action response');
        response.actions.forEach((a, i) => requireValue(a.truck_id === candidates[i].truck_id
          && a.leg_sequence === candidates[i].leg_sequence && a.decision_time_s === time
          && a.interface_hash === hash && spec.action_space_kmh.includes(a.relative_action_kmh), 'Wrong truck/leg/action response'));
        requireValue(env.now() === time, 'Simulation advanced during truck decision');
        reconcile();
        requireValue(candidates.every(c => sessions.get(c.truck_id)?.leg === c.leg_sequence), 'Truck leg changed during decision');
        const previous = dataset.chapter5TrajectoryGroups.at(-1);
        if (previous) {
          requireValue(previous.reward?.time_end_s === time, 'Missing post-action reward');
          previous.next_candidates = candidates.map(c => ({truck_id: c.truck_id, leg_sequence: c.leg_sequence,
            decision_time_s: time, interface_hash: hash, state_vector: c.state_vector}));
          previous.next_fleet_state = fleet;
          previous.next_eligible_mask = mask;
        }
        candidates.forEach((c, i) => {
          const a = response.actions[i].relative_action_kmh;
          const truck = env.trucks().find(t => String(t.id) === c.truck_id);
          const target = env.baseline(truck) + a, range = env.range(truck);
          control.targetSpeedsByConvoyId[c.truck_id] = target;
          control.activeActionsByConvoyId[c.truck_id] = a;
          control.previousActionsByConvoyId[c.truck_id] = a;
          c.relative_action_kmh = a;
          c.controlled_role = 'self'; c.controlled_truck_id = c.truck_id;
          const s = c.state_input;
          dataset.chapter5ControlDecisionRows.push({decision_time_s: time, truck_id: c.truck_id,
            leg_sequence: c.leg_sequence, interface_hash: hash, controlled_role: 'self',
            controlled_truck_id: c.truck_id, counterpart_truck_id: c.counterpart_truck_id,
            route_id: c.route_id, phase: c.phase, risk_node_id: c.risk_node_id,
            risk_distance_m: s.context_valid ? s.node_distance : null,
            risk_eta_s: s.context_valid ? s.node_eta : null,
            risk_forecast_horizon_s: s.context_valid ? s.forecast_horizon : null,
            predicted_obstruction_probability: s.context_valid ? s.operational_probability : null,
            relative_action_kmh: a, route_baseline_speed_kmh: env.baseline(truck), commanded_target_speed_kmh: target,
            normal_effective_target_kmh: env.clamp(env.baseTarget(truck), range.minKmh, range.maxKmh),
            controlled_effective_target_kmh: env.clamp(target, range.minKmh, range.maxKmh),
            actual_speed_kmh: s.current_speed, context_valid: s.context_valid,
            counterpart_valid: s.counterpart_valid, new_session: c.new_session,
            clipped_field_count: c.clipped_field_count});
          log(c.truck_id, 'command', c.new_session ? 'initial' : 'renewed', {intent_kmh: target});
        });
        dataset.chapter5TrajectoryGroups.push({decision_time_s: time, interface_hash: hash,
          fleet_state: fleet, eligible_mask: mask, candidates, reward: null, next_candidates: null,
          next_fleet_state: null, next_eligible_mask: null, terminal: false, episode_end_reason: null});
        control.inferenceCount += 1; control.eligibleDecisionCount += candidates.length;
        lastDecision = time;
      } catch (error) {
        for (const id of [...sessions.keys()]) release(id, 'decision_error');
        throw error;
      } finally { busy = false; }
    }
    function captureExecution() {
      return env.trucks().filter(truck => sessions.has(String(truck.id))).map(truck => {
        const range = env.range(truck), intent = control.targetSpeedsByConvoyId[truck.id];
        const effective = env.clamp(intent, range.minKmh, range.maxKmh);
        return {truck, intent, effective, leg: legs.get(String(truck.id)),
          reason: effective === intent ? 'unrestricted' : env.limitReason(truck)};
      }).filter(row => Number.isFinite(row.intent));
    }
    function recordExecution() {
      for (const {truck, intent, effective, leg, reason} of stepSnapshot || captureExecution()) {
        const id = String(truck.id), time = env.now(), speed = Number(truck.currentSpeedKmh || 0);
        const key = `${Math.floor((time - 1e-8) / 30)}|${intent}|${effective}|${reason}|${leg}`;
        const previous = executionRows.get(id);
        if (previous?.key === key && Math.abs(previous.row.time_end_s - (time - stepSeconds)) < 1e-8) {
          Object.assign(previous.row, {time_end_s: time, duration_s: previous.row.duration_s + stepSeconds,
            actual_speed_kmh: speed, min_actual_speed_kmh: Math.min(previous.row.min_actual_speed_kmh, speed),
            max_actual_speed_kmh: Math.max(previous.row.max_actual_speed_kmh, speed),
            actual_speed_integral_kmh_s: previous.row.actual_speed_integral_kmh_s + speed * stepSeconds});
        } else {
          log(id, 'execution', reason, {leg_sequence: leg, time_start_s: time - stepSeconds, time_end_s: time, duration_s: stepSeconds,
            intent_kmh: intent, effective_target_kmh: effective, actual_speed_kmh: speed,
            min_actual_speed_kmh: speed, max_actual_speed_kmh: speed, actual_speed_integral_kmh_s: speed * stepSeconds});
          executionRows.set(id, {key, row: dataset.chapter5ControlLifecycleRows.at(-1)});
        }
      }
      stepSnapshot = null;
    }
    return {decide, reconcile, phaseChanged, fleetState, recordExecution,
      beginStep: () => { stepSnapshot = captureExecution(); },
      close: reason => { for (const id of [...sessions.keys()]) release(id, reason); }};
  }
  const api = {create};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Chapter5TruckControl = api;
})(globalThis);
